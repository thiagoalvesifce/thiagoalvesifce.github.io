def fat(n):
	if n == 0:
		return 1
	return n*fat(n-1)

def insPos(lista, tam, x, pos):
	listaNova = []	
	for i in range(tam+1):
		if i < pos:
			listaNova.append(lista[i])
		elif i == pos:
			listaNova.append(x)
		else:
			listaNova.append(lista[i-1])

	return listaNova

def allPerm(lista, tam):
	if tam == 1:
		return [lista]
	
	listaNova = []
	for i in range(1,tam):
		listaNova.append(lista[i])
	perm = allPerm(listaNova, tam-1)
	permTotal = []
	for i in range(fat(tam-1)):
		for j in range(tam):
			permTotal.append(insPos(perm[i], tam-1, lista[0], j))

	return permTotal

print allPerm([1,2,3], 3)
print allPerm([1,2,3,4], 4)
